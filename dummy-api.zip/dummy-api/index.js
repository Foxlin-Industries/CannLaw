const express = require('express');
const app = express();
const port = 7048;

app.use(express.json());

app.post('/api/accept', (req, res) => {
  console.log('Received data:');
  console.log(req.body);
  res.status(200).send('Data received');
});

app.listen(port, () => {
  console.log(`Dummy API listening at http://localhost:${port}`);
});
