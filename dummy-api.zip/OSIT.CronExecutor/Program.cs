﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
using DotNetEnv;
using StackExchange.Redis;

class Program
{
    static async Task<int> Main(string[] args)
    {
        try
        {
            // Load environment variables
            var envFile = File.Exists("OSIT.CronExecutor.env") ? "OSIT.CronExecutor.env" : "local.env";
            Env.Load(envFile);

            var valkeyConnectionString = Environment.GetEnvironmentVariable("VALKEY_CONNECTION_STRING");
            var apiEndpoint = Environment.GetEnvironmentVariable("API_ENDPOINT");
            var apiBearerToken = Environment.GetEnvironmentVariable("API_BEARER_TOKEN");

            if (string.IsNullOrEmpty(valkeyConnectionString) || string.IsNullOrEmpty(apiEndpoint))
            {
                throw new Exception("Missing required environment variables.");
            }

            // Connect to Valkey
            var redis = await ConnectionMultiplexer.ConnectAsync(valkeyConnectionString);
            var db = redis.GetDatabase();

            // Retrieve all keys and values
            var server = redis.GetServer(redis.GetEndPoints()[0]);
            var keys = server.Keys();
            var cacheData = new Dictionary<string, string>();

            foreach (var key in keys)
            {
                string keyStr = key.ToString();
                if (!string.IsNullOrEmpty(keyStr))
                {
                    var value = await db.StringGetAsync(key);
                    if (!value.IsNullOrEmpty)
                    {
                        cacheData[keyStr] = value.ToString();
                    }
                }
            }

            // Serialize data
            var jsonPayload = JsonSerializer.Serialize(cacheData);

            // Send data to API
            using var client = new HttpClient();

            // If an API bearer token was provided in the env file, attach it as a Bearer token
            if (!string.IsNullOrEmpty(apiBearerToken))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiBearerToken);
            }

            var content = new StringContent(jsonPayload, System.Text.Encoding.UTF8, "application/json");
            var response = await client.PostAsync(apiEndpoint, content);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"API request failed with status code {response.StatusCode}");
            }

            Console.WriteLine("Successfully retrieved and sent cache data.");
            return 0; // Success
        }
        catch (Exception ex)
        {
            await File.AppendAllTextAsync("error.log", $"{DateTime.UtcNow}: {ex.ToString()}\n");
            return 1; // Failure
        }
    }
}
